<?php if ($modules) { ?>
<aside id="column-left" class="col-sm-3 hidden-xs">
  <?php foreach ($modules as $module) { ?>
   <?php echo $module; ?>
<?php } ?>
</aside>
<?php } ?>
