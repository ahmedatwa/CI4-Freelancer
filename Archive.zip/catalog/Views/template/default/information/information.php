<?php echo $header;?><?php echo $menu;?>
<main>
<div class="container margin_100_40">
<h1><?php echo $heading_title; ?></h1>
	<p><?php echo $description; ?></p>
</div>
<!-- /container -->
</main>
<!-- /main -->
<?php echo $footer;?>