<?php echo $header;?><?php echo $menu;?>
<main>
		<div class="hero_single inner_pages background-image" data-background="url(img/home_section_1.jpg)">
			<div class="opacity-mask" data-opacity-mask="rgba(0, 0, 0, 0.6)">
				<div class="container">
					<div class="row justify-content-center">
						<div class="col-xl-9 col-lg-10 col-md-8">
							<h1><?php echo $heading_title; ?></h1>
							<!-- <p>A successful restaurant experience</p> -->
						</div>
					</div>
					<!-- /row -->
				</div>
			</div>
		</div>
		<!-- /hero_single -->
		<div class="container margin_60_40">
		    <p><?php echo $description; ?></p>
		</div>
		<!-- /container -->

	</main>
	<!-- /main -->
<?php echo $footer;?>