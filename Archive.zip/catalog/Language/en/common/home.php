<?php 
        
return [
    'text_title'           => 'Home',
    'text_warning'         => 'Some information you entered doesn\'t look right.',
    'list' => [
    'button_login'         => 'Login',
    'text_forget_password' => 'Forgot Password',
    'text_keep_signed'     => 'Keep me signed in',
    'text_copyright'       => 'copyright © 2018 Bootstrapdash. All rights reserved.',
    'text_welcome'         => 'Welcome Back !',   
    // Entry
    'entry_email'          => 'Email',
    'entry_password'       => 'Password',
    ]
];
