<?php
return [
'list' => [
// Heading
'heading_title'  => 'Categories',
// Text
'text_all_categories'  => 'Browse All Categories',
'text_categories'  => 'Categories',
'text_found' => 'Found',
],
];