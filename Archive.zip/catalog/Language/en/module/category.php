<?php
return [
// Heading
'heading_title' => 'Categories',
];