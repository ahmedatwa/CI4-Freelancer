<?php

return [
    // Text
'text_success'     => 'You have modified Bids!',
'error_permission' => 'You do not have permission to modify Bids!',
    'list' => [
'heading_title'          => 'Bids',
'text_list'              => 'Bids List',
// Column
'column_name'            => 'Name',
'column_freelancer' => 'Freelancer',
'column_open'       => 'Open',
   ]
];
