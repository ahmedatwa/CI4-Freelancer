<?php
return [
  'text_success'      => 'Success: You have modified Jobs!',
  'error_permission'  => 'Warning: You do not have permission to modify Jobs!',
'list' => [
// Heading
'heading_title'     => 'Job',
// Text
'text_list'         => 'Jobs List',
// Column
'column_name'       => 'Name',
'column_status'     => 'Status',
'column_action'     => 'Action',
  ],
];