<?php
return [
  'text_success'      => 'Success: You have modified Bids!',
  'error_permission'  => 'Warning: You do not have permission to modify Bids!',
'list' => [
// Heading
'heading_title'     => 'Bids',
// Text
'text_list'         => 'Bids List',
// Column
'column_name'       => 'Name',
'column_status'     => 'Status',
'column_action'     => 'Action',
  ],
];