<?php
return [
'text_success'     => 'Success: You have modified category module!',
'error_permission' => 'Warning: You do not have permission to modify category module!',
'list' => [
// Heading
'heading_title' => 'Category',
// Text
'text_module'   => 'Modules',
'text_edit'     => 'Edit Category Module',
// Entry
'entry_status'  => 'Status',
],
];