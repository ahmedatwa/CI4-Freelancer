<?php 

return [
    'error_install' => 'Warning: Install folder still exists and should be deleted for security reasons!',
'list' => [
	    'heading_dashboard'   => 'Dashboard',
    ],
];
