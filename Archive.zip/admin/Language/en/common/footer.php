<?php
return [
    'text_footer'       => 'WebSite &copy; ' . date('Y') . ' All Rights Reserved.',
    'text_version'      => 'Version %s',
];
