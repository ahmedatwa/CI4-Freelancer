<?php 

return [
	'admin_panel_title' => 'ACME - Dashboard',
	'text_logout'       => 'Logout',
	'text_profile'      => 'Profile',
	'text_activity'     => 'Activity',
	'text_setting'      => 'Setting',
];