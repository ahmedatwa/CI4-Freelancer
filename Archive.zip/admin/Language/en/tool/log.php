<?php

return [
    'text_success' => 'You have cleared all log files!',
    'not_found'   => 'No log Files to be deleted!',
    'error_delete' => 'Unknown error occured during code excution!',
    'error_permission' => 'You do not have permission to clear error log!',
'list'=> [
    'heading_title' => 'Error Log',
    'text_list'     => 'Error List',
    'text_delete'   => 'Clear',
    ]
];
