<?php

return [
    // Text
	'text_success'     => 'You have modified Wallet!',
	'error_permission' => 'You do not have permission to modify Wallet!',
	'list' => [
	'heading_title'    => 'Wallet',
	'text_form'        => 'Wallet Form',
	// Column
	'column_customer'  => 'Customer',
	'column_total'     => 'Total',
	'column_status'     => 'Status',
   ]
];
