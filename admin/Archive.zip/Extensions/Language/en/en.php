<?php

return [
	// Button
	'button_cancel' => 'Cancel',
	// Column
	'column_status' => 'Status',
	'column_action' => 'Action',
	'text_no_results'   => 'No Results !',

];
