<?php

return [
 // Text
'heading_title'     => 'Project Bidding',
'text_list'         => 'Project Bidding List',
// Column
'column_name'       => 'Name',
'column_freelancer' => 'Freelancer',
'column_delivery'   => 'Delivery ',
];
