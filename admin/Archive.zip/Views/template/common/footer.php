<footer id="footer">
        <?php echo $text_footer; ?>
</footer>
</div> 
</body>
</html>