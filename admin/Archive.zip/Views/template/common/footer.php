<footer id="footer" class="text-center">
	<?php echo $text_footer; ?>
</footer>
</div> 
</body>
</html>