<?php echo $header; ?><?php echo $column_left; ?>
<div id="content">
	<div class="page-header">
		<div class="container-fluid">
			<h1><?php echo $heading_title; ?> </h1>
		</div>
	</div>
	<div class="container-fluid">
		<div class="card">
			<div class="card-header"><i class="fas fa-exclamation-triangle"></i> <?php echo $heading_title; ?></div>
			<div class="card-body">
				<p class="text-center"><?php echo $text_permission; ?></p>
			</div><!-- Card Body -->
		</div><!-- Card -->
	</div><!-- container-fluid -->
</div>
<?php echo $footer; ?>