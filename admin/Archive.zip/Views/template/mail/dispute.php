<?php echo $text_dispute_id ?> <?php echo $dispute_id ?>
<?php echo $text_date_added ?> <?php echo $date_added ?>

<?php echo $text_dispute_status ?>

<?php echo $dispute_status ?>

<?php if ($comment) { ?>

<?php echo $text_comment ?>

<?php echo $comment ?>
<?php echo $text_footer ?>
<?php } else { ?>
<?php echo $text_footer ?>
<?php } ?>