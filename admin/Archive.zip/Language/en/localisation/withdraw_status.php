<?php
return [
'error_permission' => 'Warning: You do not have permission to modify withdraw statuses!',
'text_success'     => 'Success: You have modified withdraw statuses!',

'list' => [	
// Heading
'heading_title'    => 'Withdraw Statuses',

// Text
'text_list'        => 'Withdraw Status List',
'text_add'         => 'Add Withdraw Status',
'text_edit'        => 'Edit Withdraw Status',

// Column
'column_name'      => 'Withdraw Status Name',
'column_action'    => 'Action',

// Entry
'entry_name'       => 'Withdraw Status Name',
  ]
];