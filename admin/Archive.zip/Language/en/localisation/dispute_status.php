<?php
return [
'error_permission' => 'Warning: You do not have permission to modify dispute statuses!',
'text_success'     => 'Success: You have modified dispute statuses!',

'list' => [	
// Heading
'heading_title'    => 'Dispute Statuses',

// Text
'text_list'        => 'Dispute Status List',
'text_add'         => 'Add Dispute Status',
'text_edit'        => 'Edit Dispute Status',

// Column
'column_name'      => 'Dispute Status Name',
'column_action'    => 'Action',

// Entry
'entry_name'       => 'Dispute Status Name',
  ]
];