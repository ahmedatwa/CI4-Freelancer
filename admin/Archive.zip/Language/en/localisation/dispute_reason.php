<?php
return [
'error_permission' => 'Warning: You do not have permission to modify dispute reasons!',
'text_success'     => 'Success: You have modified dispute reasons!',
'list' => [
// Heading
'heading_title'    => 'Dispute Reasons',

// Text
'text_list'        => 'Dispute Reason List',
'text_add'         => 'Add Dispute Reason',
'text_edit'        => 'Edit Dispute Reason',

// Column
'column_name'      => 'Dispute Reason Name',
'column_action'    => 'Action',

// Entry
'entry_name'       => 'Dispute Reason Name',
  ]
];