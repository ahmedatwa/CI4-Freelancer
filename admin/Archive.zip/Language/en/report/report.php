<?php
return [
'text_success'  => 'Success: You have modified reports!',
'list' => [
	// Text
	'heading_title' => 'Reports',
	'text_list'     => 'Report List',
	'text_type'     => 'Choose the report type',
	'text_filter'   => 'Filter',
	'help_list'     => '',
],
];