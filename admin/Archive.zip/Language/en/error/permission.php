<?php 

return [
    'text_title'   => 'Permission',
    'heading_title' => 'Permission Denied!',
    'list' => [
    'text_permission' => 'You do not have permission to access this page, please refer to your system administrator.',
    ],
];
