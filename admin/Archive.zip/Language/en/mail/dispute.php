<?php
// Text
return [
'text_subject'        => '%s - Dispute Update %s',
'text_dispute_id'     => 'Dispute ID:',
'text_date_added'     => 'Dispute Date:',
'text_dispute_status' => 'Your Dispute has been updated to the following status:',
'text_comment'        => 'The comments for your Dispute are:',
'text_footer'         => 'Please reply to this email if you have any questions.',
];