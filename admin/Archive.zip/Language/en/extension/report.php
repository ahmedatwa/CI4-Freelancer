<?php
return [
// Text
'text_success'      => 'Success: You have modified reports!',
'list' => [
'heading_title'     => 'Reports',
'text_list'         => 'Reports List',
// Column
'column_name'       => 'Report Name',
'column_status'     => 'Status',
'column_sort_order' => 'Sort Order',
'column_action'     => 'Action',
],
];