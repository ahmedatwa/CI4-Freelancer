<?php
return [
	'text_success'      => 'Success: You have modified Project Bidding!',
	'error_permission'  => 'Warning: You do not have permission to modify Project Bidding!',
	'list' => [
	// Heading
	'heading_title'     => 'Bidding',
	// Text
	'text_list'         => 'Bidding List',
	// Column
	'column_name'       => 'Name',
	'column_status'     => 'Status',
	'column_action'     => 'Action',
  ],
];