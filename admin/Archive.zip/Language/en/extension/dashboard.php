<?php
return [
  'text_success'      => 'Success: You have modified dashboards!',
  'error_permission'  => 'Warning: You do not have permission to modify dashboards!',
'list' => [
// Heading
'heading_title'     => 'Dashboard',
// Text
'text_list'         => 'Dashboard List',
// Column
'column_name'       => 'Name',
'column_width'      => 'Width',
'column_status'     => 'Status',
'column_sort_order' => 'Sort Order',
'column_action'     => 'Action',
  ],
];