<?php
return [
  'text_success'      => 'Success: You have modified Wallet!',
  'error_permission'  => 'Warning: You do not have permission to modify Wallet!',
'list' => [
// Heading
'heading_title'     => 'Wallet',
// Text
'text_list'         => 'Wallet List',
// Column
'column_name'       => 'Name',
'column_income'     => 'Income',
'column_withdrawn'  => 'Withdrawn',
'column_available'  => 'Available',
'column_used'       => 'Used',
'column_date_added' => 'Date Added',
'column_action'     => 'Action',
  ],
];