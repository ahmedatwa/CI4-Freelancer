<?php
return [
	'text_success'      => 'Success: You have modified payments!',
'list' => [
	// Heading
	'heading_title'     => 'Payments',
	// Text
	'text_list'         => 'Payment List',
	// Column
	'column_name'       => 'Payment Method',
	'column_status'     => 'Status',
	'column_sort_order' => 'Sort Order',
	'column_action'     => 'Action',
	// Error
	'error_permission'  => 'Warning: You do not have permission to modify payments!',
   ]
];