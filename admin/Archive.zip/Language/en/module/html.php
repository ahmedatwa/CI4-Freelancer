<?php
return [
 // Error
'error_permission'  => 'Warning: You do not have permission to modify HTML Content module!',
'text_success'      => 'Success: You have modified HTML Content module!',
    'list' => [
// Heading
'heading_title'     => 'HTML Content',

// Text
'text_extension'    => 'Extensions',
'text_edit'         => 'Edit HTML Content Module',

// Entry
'entry_name'        => 'Module Name',
'entry_title'       => 'Heading Title',
'entry_description' => 'Description',
'entry_status'      => 'Status',
 ]
];