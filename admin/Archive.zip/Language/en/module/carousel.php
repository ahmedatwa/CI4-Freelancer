<?php
return [
'text_success'     => 'Success: You have modified carousel module!',
'error_permission' => 'Warning: You do not have permission to modify carousel module!',

'list' => [
// Heading
'heading_title'    => 'Carousel',

// Text
'text_extension'   => 'Extensions',
'text_edit'        => 'Edit Carousel Module',

// Entry
'entry_name'     => 'Module Name',
'entry_banner'   => 'Banner',
'entry_width'    => 'Width',
'entry_height'   => 'Height',
'entry_status'   => 'Status',
'entry_autoplay' => 'Autoplay',
'entry_dots'     => 'Dots',
'entry_infinite' => 'Infinite',
'entry_arrows'   => 'Arrows',
],
];