<?php
return [
'text_success'     => 'Success: You have modified freelancer module!',
'error_permission' => 'Warning: You do not have permission to modify freelancer module!',
'list'             => [
// Heading
'heading_title'    => 'Highest Rated Freelancers',
// Text
'text_module'      => 'Modules',
'text_edit'        => 'Edit Freelancer Module',
// Entry
'entry_status'     => 'Status',
'entry_limit'      => 'Limit',
],
];