<?php
return [
'text_success'     => 'Success: You have modified featured module!',
'error_permission' => 'Warning: You do not have permission to modify featured module!',
'list'             => [
// Heading
'heading_title'    => 'Featured Projects',
// Text
'text_module'      => 'Modules',
'text_edit'        => 'Edit Featured Module',
// Entry
'entry_status'     => 'Status',
'entry_limit'      => 'Limit',
],
];