<?php 

return [
	'text_success'      => 'An email with a confirmation link has been sent your admin email address.',
	'error_email'       => 'Warning: The E-Mail Address wasn\'t found in our records, please try again!',
'list' => [
	'heading_title' => 'Reset Password',
	'entry_email'       => 'Email Address',
	'button_reset'      => 'Reset',
   ],

];
