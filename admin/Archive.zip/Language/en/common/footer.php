<?php
return [
    'text_footer'       => '%s &copy; ' . date('Y') . ' All Rights Reserved.',
    'text_version'      => 'Version %s',
];
