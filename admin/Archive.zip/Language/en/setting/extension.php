<?php
return [
	'text_success' => 'Success: You have modified extensions!',
'list' => [
// Heading
'heading_title' => 'Extensions',
// Text
'text_list'     => 'Extension List',
'text_type'     => 'Choose the extension type',
'text_filter'   => 'Filter',
// Column
'column_name'   => 'Extension Name'
],
];