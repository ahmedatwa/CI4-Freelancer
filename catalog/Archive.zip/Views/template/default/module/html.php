<?php 
if ($heading_title) {
  echo $heading_title;
 } 
 echo $html; 
 ?>
