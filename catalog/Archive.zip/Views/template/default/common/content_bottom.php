<?php foreach ($modules as $module) {
	echo $module;
} ?>
