<?php
return [
// Heading
'heading_title'    => 'Freelancers Bidding',
// Text
];