<?php
return [
// Heading
'heading_title' => 'Featured Projects',
// text
'text_browse' => 'Browse All Porjects',
'text_apply' => 'Apply Now',

];