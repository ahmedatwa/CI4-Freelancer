<?php
return [
// Heading
'heading_title' => 'Popular Job Categories',
];