<?php
return [
// Text
 'text_error' => 'Information Page Not Found!',
];