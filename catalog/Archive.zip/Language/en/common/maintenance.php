<?php
return [
// Heading
'heading_title'    => 'Maintenance',

// Text
'text_maintenance' => 'Maintenance',
'text_message'     => 'We are currently performing some scheduled maintenance. <br/>We will be back as soon as possible. Please check back soon.',
];