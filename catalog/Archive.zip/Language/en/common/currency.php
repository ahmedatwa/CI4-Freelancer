<?php
return [
// Text
'text_currency' => 'Currency',

];