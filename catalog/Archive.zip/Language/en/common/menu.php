<?php 
        
return [
    'text_menu'        => 'Menu',
    'text_login'       => 'Login',
    'text_register'    => 'Join Free',
    'text_home'        => 'Home',
    'text_jobs'        => 'Browse Jobs',
    // Buttons
    'button_logout' => 'Logout',
    'button_dashboard' => 'Dashboard',
    'button_messages' => 'Messages',
];
