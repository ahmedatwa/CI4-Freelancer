<?php 
        
return [
	'text_home'                 => 'Home',
	'text_register'             => 'Sign Up',
	'text_home'                 => 'Home',
	'text_how_it_works'         => 'How It Works',
	'text_logout'               => 'Logout',
	'text_login'                => 'Login',
	'text_projects'             => 'Browse Projects',
	'text_dashboard'            => 'Dashboard',
	'text_setting'              => 'Settings',
	'text_blog'                 => 'Blog',
	'text_add_project'          => 'Post a Project',
	'text_profile'              => 'View Profile',
	'text_finance'              => 'Finance',
	'text_account'              => 'Account',
	'text_balances'             => 'Balances',
	'text_deposite_funds'       => 'Deposit Funds',
	'text_withdraw_funds'       => 'Withdraw Funds',
	'text_transactions_history' => 'Transaction History'
];
