<?php

return [
    'heading_title' => '404 Not Found',
    'text_not_found' => '404 Not Found',
    'text_404' => '404',
    'text_sorry' => 'We\'re sorry, but the page you were looking for doesn\'t exist',
];
