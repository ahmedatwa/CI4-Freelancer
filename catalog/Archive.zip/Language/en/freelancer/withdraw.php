<?php 
        
return [
    'heading_title'       => 'Withdrawal Request',
    // column
    'column_method'       => 'Method',
    'column_fee'          => 'Fee',
    'column_currency'     => 'Currency',
    'column_total'        => 'Total',
    'column_requested_at' => 'Requested at',
    'column_amount'       => 'Amount',
    'column_status'       => 'status',
    'column_date'         => 'Process Date',
    'column_date_added'   => 'Date Added',
    
    // text
    'text_balance'        => 'Balance',
    'text_total'          => 'Total',
    // entry
    'entry_amount'        => 'Amount',
    // button
    'button_submit'       => 'Request',
    'text_success'        => 'Withdrawal request has been submitted and will be reviewed',
    
];
