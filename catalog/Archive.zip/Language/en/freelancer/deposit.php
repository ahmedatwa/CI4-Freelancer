<?php 
        
return [
    'heading_title' => 'Deposit Funds',
    'text_fee'      => 'Processing Fee',
    'text_total'    => 'Total',
    'entry_amount'  => 'Deposit Amount',
    'text_success'  => 'Your Account has been accredited'
];
