<?php 
        
return [
    'heading_title'       => 'Dispute',

    'text_success'        => 'Dispute request has been submitted and will be reviewed by our team',
    
];
