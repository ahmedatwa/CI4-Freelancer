<?php
// Text
return [
'text_subject'        => '%s - Thank you for registering',
'text_welcome'        => 'Welcome and thank you for registering at %s!',
'text_login'          => 'Your account has now been created and you can log in by using your email address and password by visiting our website',

'text_service'        => 'Upon logging in, you will be able to access other services including managing project, hire and editing your account information.',
'text_thanks'         => 'Thanks,',
];