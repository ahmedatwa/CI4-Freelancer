<?php
// Text
return [
'text_subject'      => '%s - Project %s',
'text_received'     => 'Project has been completed by Freelancer',
'text_pay'          => 'Please login and pay the Freelancer if you are 100% satisfied about the Service',
'text_project_id'     => 'Project ID:',
];
