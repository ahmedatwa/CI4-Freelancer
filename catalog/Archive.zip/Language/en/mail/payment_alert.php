<?php
// Text
return [
'text_subject'  => '%s - You have got money project ID',
'text_received' => 'Congratulations! You have received a payment from the Employer for project ID #%d',
'text_amount'   => 'You have received: %d',
];