<?php
return [
'heading_title'       => 'Browse all Categories',
'text_by' => 'Browse by Category',

];