<?php
return [
// Heading
'heading_title'                 => 'Recent Activity',

// Text
'text_activity_customer_update'         => 'Your account details have been updated.',
'text_activity_customer_password'       => 'Your account password has been updated.',

'text_activity_project_winner_selected' => 'Congrats! project_id= has been awarded.',

'text_activity_customer_transfer_funds'    => 'employer_id= transfered freelancer_id= funds for <a href="project_id=">project</a>.',

'text_activity_offer_accepted'             => 'freelancer_id= Accepted the job proposal for <a href="project_id=">project</a>.',
'text_activity_offer_selected'             => 'freelancer_id= job proposal for <a href="project_id=">project</a>.',
'text_activity_customer_new_message'       => 'You have received new for message <a href="project_id=">project</a>.',
];