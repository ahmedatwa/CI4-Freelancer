<?php 
        
return [
    'text_warning'           => 'Please check the form for errors.',
    'text_success'           => 'Feedback sent! Thank you.',
    'heading_title'          => 'Projects Awaiting Feedback',
    // column
    'column_name'       => 'Project Name',
    'column_employer'   => 'Employer',
    'column_status'     => 'Project Status',
    'column_action'     => 'Action',
    'column_freelancer' => 'Freelancer'

];
