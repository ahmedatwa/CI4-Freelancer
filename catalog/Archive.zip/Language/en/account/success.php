<?php
return [
// Heading
	'heading_title' => 'Success!',

// Text
	'text_message'  => '<p>Congratulations! Your new account has been successfully created!</p> <p>You can now take advantage of member privileges to enhance your online  experience with us.</p> <p>A confirmation has been sent to the provided e-mail address. If you have not received it within the hour, please <a href="%s">contact us</a>.</p>',

'text_account'  => 'Account',
'text_success'  => 'Success',
];