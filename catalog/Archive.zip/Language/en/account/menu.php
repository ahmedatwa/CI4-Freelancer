<?php 
        
return [
    'text_dashboard'       => 'Dashboard',
    'text_messages'        => 'Inbox',
    'text_reviews'         => 'Feedback',
    'text_settings'        => 'Settings',
    'text_logout'          => 'Logout',
    'text_projects'        => 'Projects',
    'text_my_projects' => 'My Projects',
    'text_manage_bidders'  => 'Manage Bidders',
    'text_active_bids'     => 'My Active Bids',
    'text_post_project'    => 'Post a Project',
];
