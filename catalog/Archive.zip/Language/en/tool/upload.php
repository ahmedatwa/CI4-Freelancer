<?php

return [
// Text
'text_upload'    => 'Your file was successfully uploaded!',
// Error
'error_filename' => 'Filename must be between 3 and 64 characters!',
'error_filetype' => 'Invalid file type!',
'error_upload'   => 'Upload required!',

];
